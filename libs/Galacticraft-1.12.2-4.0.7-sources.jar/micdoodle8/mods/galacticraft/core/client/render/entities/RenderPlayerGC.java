/*
 * Copyright (c) 2023 Team Galacticraft
 *
 * Licensed under the MIT license.
 * See LICENSE file in the project root for details.
 */

package micdoodle8.mods.galacticraft.core.client.render.entities;

import java.lang.reflect.Field;
import java.util.List;

import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.entity.RenderLivingBase;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.client.renderer.entity.layers.LayerArmorBase;
import net.minecraft.client.renderer.entity.layers.LayerCustomHead;
import net.minecraft.client.renderer.entity.layers.LayerHeldItem;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ResourceLocation;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.fml.client.FMLClientHandler;

import micdoodle8.mods.galacticraft.api.entity.ICameraZoomEntity;
import micdoodle8.mods.galacticraft.core.GCBlocks;
import micdoodle8.mods.galacticraft.core.blocks.BlockMulti;
import micdoodle8.mods.galacticraft.core.client.model.ModelPlayerGC;
import micdoodle8.mods.galacticraft.core.client.render.entities.layer.LayerFrequencyModule;
import micdoodle8.mods.galacticraft.core.client.render.entities.layer.LayerHeldItemGC;
import micdoodle8.mods.galacticraft.core.client.render.entities.layer.LayerOxygenGear;
import micdoodle8.mods.galacticraft.core.client.render.entities.layer.LayerOxygenMask;
import micdoodle8.mods.galacticraft.core.client.render.entities.layer.LayerOxygenParachute;
import micdoodle8.mods.galacticraft.core.client.render.entities.layer.LayerOxygenTanks;
import micdoodle8.mods.galacticraft.core.client.render.entities.layer.LayerShield;
import micdoodle8.mods.galacticraft.core.client.render.entities.layer.LayerThermalPadding;
import micdoodle8.mods.galacticraft.core.tile.TileEntityMulti;
import micdoodle8.mods.galacticraft.core.util.ConfigManagerCore;
import micdoodle8.mods.galacticraft.core.util.GCCoreUtil;
import micdoodle8.mods.galacticraft.planets.mars.blocks.BlockMachineMars;
import micdoodle8.mods.galacticraft.planets.mars.blocks.MarsBlocks;

import org.lwjgl.opengl.GL11;

/**
 * This renders the thermal armor (unless RenderPlayerAPI is installed). The
 * thermal armor render is done after the corresponding body part of the player
 * is drawn. This ALSO patches RenderPlayer so that it uses ModelPlayerGC in
 * place of ModelPlayer to draw the player. <p> Finally, this also adds a hook
 * into applyRotations so as to fire a RotatePlayerEvent - used by the Cryogenic
 * Chamber
 *
 * @author User
 */
public class RenderPlayerGC extends RenderPlayer
{

    public static ResourceLocation thermalPaddingTexture0;
    public static ResourceLocation thermalPaddingTexture1;
    public static ResourceLocation thermalPaddingTexture1_T2;
    public static ResourceLocation heatShieldTexture;
    public static boolean          flagThermalOverride = false;
    private static Boolean         isSmartRenderLoaded = null;

    public RenderPlayerGC()
    {
        this(false);
    }

    public RenderPlayerGC(boolean smallArms)
    {
        super(FMLClientHandler.instance().getClient().getRenderManager(), smallArms);
        this.mainModel = new ModelPlayerGC(0.0F, smallArms);
        this.addGCLayers();
    }

    private void addGCLayers()
    {
        Field f1 = null;
        Field f2 = null;
        Field f3 = null;
        try
        {
            f1 = LayerArmorBase.class.getDeclaredField(GCCoreUtil.isDeobfuscated() ? "renderer" : "field_177190_a");
            f1.setAccessible(true);
        } catch (Exception ignore)
        {}
        // The following code removes the vanilla skull and item layer renderers
        // and replaces them with the Galacticraft ones
        // Also updates all armor layers (including layers added by other mods)
        // to reflect GC model limb positioning
        int itemLayerIndex = -1;
        int skullLayerIndex = -1;
        for (int i = 0; i < this.layerRenderers.size(); i++)
        {
            LayerRenderer layer = this.layerRenderers.get(i);
            if (layer instanceof LayerHeldItem)
            {
                itemLayerIndex = i;
            }
            else if (layer instanceof LayerArmorBase)
            {
                if (f1 != null)
                {
                    try
                    {
                        f1.set(layer, this);
                    } catch (Exception ignore)
                    {}
                }
            }
            else if (layer instanceof LayerCustomHead)
            {
                skullLayerIndex = i;
            }
        }
        if (skullLayerIndex >= 0)
        {
            this.setLayer(skullLayerIndex, new LayerCustomHead(this.getMainModel().bipedHead));
        }
        if (itemLayerIndex >= 0 && !ConfigManagerCore.disableVehicleCameraChanges)
        {
            this.setLayer(itemLayerIndex, new LayerHeldItemGC(this));
        }

        this.addLayer(new LayerOxygenTanks(this));
        this.addLayer(new LayerOxygenGear(this));
        this.addLayer(new LayerOxygenMask(this));
        this.addLayer(new LayerOxygenParachute(this));
        this.addLayer(new LayerFrequencyModule(this));

        this.addLayer(new LayerThermalPadding(this));

        RenderPlayerGC.thermalPaddingTexture0 = new ResourceLocation("galacticraftplanets", "textures/misc/thermal_padding_0.png");
        RenderPlayerGC.thermalPaddingTexture1 = new ResourceLocation("galacticraftplanets", "textures/misc/thermal_padding_1.png");
        RenderPlayerGC.thermalPaddingTexture1_T2 = new ResourceLocation("galacticraftplanets", "textures/misc/thermal_padding_t2_1.png");
        RenderPlayerGC.heatShieldTexture = new ResourceLocation("galacticraftplanets", "textures/misc/shield.png");

        this.addLayer(new LayerShield(this));
    }

    private <V extends EntityLivingBase, U extends LayerRenderer<V>> void setLayer(int index, U layer)
    {
        this.layerRenderers.set(index, (LayerRenderer<AbstractClientPlayer>) layer);
    }

    public RenderPlayerGC(RenderPlayer old, boolean smallArms)
    {
        super(FMLClientHandler.instance().getClient().getRenderManager(), smallArms);
        this.mainModel = new ModelPlayerGC(0.0F, smallArms);

        // Preserve any layers added by other mods, for example
        // WearableBackpacks
        Class clazz = old.getClass().getSuperclass();
        Field f = null;
        do
        {
            try
            {
                f = clazz.getDeclaredField(GCCoreUtil.isDeobfuscated() ? "layerRenderers" : "field_177097_h");
                f.setAccessible(true);
            } catch (Exception ignore)
            {}
            clazz = clazz.getSuperclass();
        } while (f == null && clazz != null);
        if (f != null)
            try
            {
                List<LayerRenderer<?>> layers = (List<LayerRenderer<?>>) f.get(old);
                if (layers.size() == 0)
                {
                    // Specifically fix for compatibility with MetaMorph's
                    // non-standard "RenderSubPlayer" class
                    try
                    {
                        Field g = old.getClass().getDeclaredField("original");
                        old = (RenderPlayer) g.get(old);
                        layers = (List<LayerRenderer<?>>) f.get(old);
                    } catch (Exception ignore)
                    {}
                }
                if (layers.size() > 0)
                {
                    for (LayerRenderer<?> oldLayer : layers)
                    {
                        if (this.hasNoLayer(oldLayer.getClass()))
                        {
                            LayerRenderer newInstance = null;
                            try
                            {
                                newInstance = oldLayer.getClass().getConstructor(RenderLivingBase.class).newInstance(this);
                            } catch (Exception ignore)
                            {}
                            if (newInstance == null)
                            {
                                try
                                {
                                    newInstance = oldLayer.getClass().getConstructor(RenderPlayer.class).newInstance(this);
                                } catch (Exception ignore)
                                {}
                            }
                            if (newInstance == null)
                            {
                                try
                                {
                                    newInstance = oldLayer.getClass().getConstructor(boolean.class, ModelPlayer.class).newInstance(smallArms, this.mainModel);
                                } catch (Exception ignore)
                                {}
                            }
                            if (newInstance != null)
                            {
                                oldLayer = newInstance;
                            }
                            this.addLayer(oldLayer);
                        }
                    }
                }
            } catch (Exception e)
            {
                e.printStackTrace();
            }

        this.addGCLayers();
    }

    private boolean hasNoLayer(Class<? extends LayerRenderer> test)
    {
        for (LayerRenderer<?> oldLayer : this.layerRenderers)
        {
            if (oldLayer.getClass() == test)
                return false;
        }
        return true;
    }

    @Override
    protected void preRenderCallback(AbstractClientPlayer entitylivingbaseIn, float partialTickTime)
    {
        super.preRenderCallback(entitylivingbaseIn, partialTickTime);

        if (entitylivingbaseIn.isEntityAlive() && entitylivingbaseIn.isPlayerSleeping())
        {
            RotatePlayerEvent event = new RotatePlayerEvent(entitylivingbaseIn);
            MinecraftForge.EVENT_BUS.post(event);

            if (!event.vanillaOverride)
            {
                super.preRenderCallback(entitylivingbaseIn, partialTickTime);
            }
            else if (event.shouldRotate == null || event.shouldRotate)
            {
                entitylivingbaseIn.rotationYawHead = 0;
                entitylivingbaseIn.prevRotationYawHead = 0;
                GL11.glTranslatef(0.0F, 0.3F, 0.0F);
            }
        }
    }

    @Override
    protected void applyRotations(AbstractClientPlayer abstractClientPlayer, float par2, float par3, float par4)
    {
        if (abstractClientPlayer.isEntityAlive() && abstractClientPlayer.isPlayerSleeping())
        {
            RotatePlayerEvent event = new RotatePlayerEvent(abstractClientPlayer);
            MinecraftForge.EVENT_BUS.post(event);

            if (!event.vanillaOverride)
            {
                super.applyRotations(abstractClientPlayer, par2, par3, par4);
            }
            else if (event.shouldRotate == null)
            {
                GL11.glRotatef(abstractClientPlayer.getBedOrientationInDegrees(), 0.0F, 1.0F, 0.0F);
            }
            else if (event.shouldRotate)
            {
                float rotation = 0.0F;

                if (abstractClientPlayer.bedLocation != null)
                {
                    IBlockState bed = abstractClientPlayer.world.getBlockState(abstractClientPlayer.bedLocation);

                    if (bed.getBlock().isBed(bed, abstractClientPlayer.world, abstractClientPlayer.bedLocation, abstractClientPlayer))
                    {
                        if (bed.getBlock() == GCBlocks.fakeBlock && bed.getValue(BlockMulti.MULTI_TYPE) == BlockMulti.EnumBlockMultiType.CRYO_CHAMBER)
                        {
                            TileEntity tile = event.getEntityPlayer().world.getTileEntity(abstractClientPlayer.bedLocation);
                            if (tile instanceof TileEntityMulti)
                            {
                                bed = event.getEntityPlayer().world.getBlockState(((TileEntityMulti) tile).mainBlockPosition);
                            }
                        }

                        if (bed.getBlock() == MarsBlocks.machine && bed.getValue(BlockMachineMars.TYPE) == BlockMachineMars.EnumMachineType.CRYOGENIC_CHAMBER)
                        {
                            switch (bed.getValue(BlockMachineMars.FACING))
                            {
                                case NORTH:
                                    rotation = 0.0F;
                                    break;
                                case EAST:
                                    rotation = 270.0F;
                                    break;
                                case SOUTH:
                                    rotation = 180.0F;
                                    break;
                                case WEST:
                                    rotation = 90.0F;
                                    break;
                            }
                        }
                    }
                }

                GL11.glRotatef(rotation, 0.0F, 1.0F, 0.0F);
            }
        }
        else
        {
            if (Minecraft.getMinecraft().gameSettings.thirdPersonView != 0)
            {
                final EntityPlayer player = abstractClientPlayer;

                if (player.getRidingEntity() instanceof ICameraZoomEntity)
                {
                    Entity rocket = player.getRidingEntity();
                    float rotateOffset = ((ICameraZoomEntity) rocket).getRotateOffset();
                    if (rotateOffset > -10F)
                    {
                        GL11.glTranslatef(0, -rotateOffset, 0);
                        float anglePitch = rocket.prevRotationPitch;
                        float angleYaw = rocket.prevRotationYaw;
                        GL11.glRotatef(-angleYaw, 0.0F, 1.0F, 0.0F);
                        GL11.glRotatef(anglePitch, 0.0F, 0.0F, 1.0F);
                        GL11.glTranslatef(0, rotateOffset, 0);
                    }
                }
            }
            super.applyRotations(abstractClientPlayer, par2, par3, par4);
        }
    }

    public static class RotatePlayerEvent extends PlayerEvent
    {

        public Boolean shouldRotate    = null;
        public boolean vanillaOverride = false;

        public RotatePlayerEvent(AbstractClientPlayer player)
        {
            super(player);
        }
    }
}

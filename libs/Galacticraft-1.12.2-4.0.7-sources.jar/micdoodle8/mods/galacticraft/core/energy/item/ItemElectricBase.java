/*
 * Copyright (c) 2023 Team Galacticraft
 *
 * Licensed under the MIT license.
 * See LICENSE file in the project root for details.
 */

package micdoodle8.mods.galacticraft.core.energy.item;

import ic2.api.item.IElectricItem;
import ic2.api.item.IElectricItemManager;
import ic2.api.item.ISpecialElectricItem;
import java.util.List;
import javax.annotation.Nullable;
import mekanism.api.energy.IEnergizedItem;
import micdoodle8.mods.galacticraft.api.item.ElectricItemHelper;
import micdoodle8.mods.galacticraft.api.item.IItemElectricBase;
import micdoodle8.mods.galacticraft.core.GalacticraftCore;
import micdoodle8.mods.galacticraft.core.energy.EnergyConfigHandler;
import micdoodle8.mods.galacticraft.core.energy.EnergyDisplayHelper;
import micdoodle8.mods.galacticraft.core.items.ItemBatteryInfinite;
import micdoodle8.mods.galacticraft.core.util.CompatibilityManager;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagDouble;
import net.minecraft.nbt.NBTTagFloat;
import net.minecraft.util.NonNullList;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.Optional.Interface;
import net.minecraftforge.fml.common.Optional.InterfaceList;
import net.minecraftforge.fml.common.Optional.Method;
import net.minecraftforge.fml.common.versioning.DefaultArtifactVersion;
import net.minecraftforge.fml.relauncher.FMLInjectionData;

//@noformat
@InterfaceList(value = {
    @Interface(iface = "ic2.api.item.ISpecialElectricItem", modid = CompatibilityManager.modidIC2), 
    @Interface(iface = "ic2.api.item.IElectricItem", modid = CompatibilityManager.modidIC2),
    @Interface(iface = "mekanism.api.energy.IEnergizedItem", modid = CompatibilityManager.modidMekanism)
})
public abstract class ItemElectricBase extends Item implements IItemElectricBase, ISpecialElectricItem, IElectricItem, IEnergizedItem
{

    private static Object itemManagerIC2;
    public float transferMax;
    private DefaultArtifactVersion mcVersion = null;
    private static final int DAMAGE_RANGE = 100;

    public ItemElectricBase()
    {
        super();
        this.setMaxStackSize(1);
        this.setMaxDamage(DAMAGE_RANGE);
        this.setNoRepair();
        this.setMaxTransfer();

        this.mcVersion = new DefaultArtifactVersion((String) FMLInjectionData.data()[4]);

        if (EnergyConfigHandler.isIndustrialCraft2Loaded())
        {
            itemManagerIC2 = new ElectricItemManagerIC2();
        }
    }

    @Override
    public boolean isEnchantable(ItemStack stack)
    {
        return false;
    }

    protected void setMaxTransfer()
    {
        this.transferMax = 200;
    }

    @Override
    public float getMaxTransferGC(ItemStack itemStack)
    {
        return this.transferMax;
    }

    @Override
    public void addInformation(ItemStack itemStack, @Nullable World worldIn, List<String> tooltip, ITooltipFlag flagIn)
    {
        String color = "";
        float joules = this.getElectricityStored(itemStack);

        if (joules <= this.getMaxElectricityStored(itemStack) / 3)
        {
            color = "\u00a74";
        } else if (joules > this.getMaxElectricityStored(itemStack) * 2 / 3)
        {
            color = "\u00a72";
        } else
        {
            color = "\u00a76";
        }

        tooltip.add(color + EnergyDisplayHelper.getEnergyDisplayS(joules) + "/" + EnergyDisplayHelper.getEnergyDisplayS(this.getMaxElectricityStored(itemStack)));
    }

    /**
     * Makes sure the item is uncharged when it is crafted and not charged.
     * Change this if you do not want this to happen!
     */
    @Override
    public void onCreated(ItemStack itemStack, World par2World, EntityPlayer par3EntityPlayer)
    {
        this.setElectricity(itemStack, 0);
    }

    @Override
    public float recharge(ItemStack itemStack, float energy, boolean doReceive)
    {
        float rejectedElectricity = Math.max(this.getElectricityStored(itemStack) + energy - this.getMaxElectricityStored(itemStack), 0);
        float energyToReceive = energy - rejectedElectricity;
        if (energyToReceive > this.transferMax)
        {
            rejectedElectricity += energyToReceive - this.transferMax;
            energyToReceive = this.transferMax;
        }

        if (doReceive)
        {
            this.setElectricity(itemStack, this.getElectricityStored(itemStack) + energyToReceive);
        }

        return energyToReceive;
    }

    @Override
    public float discharge(ItemStack itemStack, float energy, boolean doTransfer)
    {
        float thisEnergy = this.getElectricityStored(itemStack);
        float energyToTransfer = Math.min(Math.min(thisEnergy, energy), this.transferMax);

        if (doTransfer)
        {
            this.setElectricity(itemStack, thisEnergy - energyToTransfer);
        }

        return energyToTransfer;
    }

    @Override
    public int getTierGC(ItemStack itemStack)
    {
        return 1;
    }

    @Override
    public void setElectricity(ItemStack itemStack, float joules)
    {
        // Saves the frequency in the ItemStack
        if (itemStack.getTagCompound() == null)
        {
            itemStack.setTagCompound(new NBTTagCompound());
        }

        float electricityStored = Math.max(Math.min(joules, this.getMaxElectricityStored(itemStack)), 0);
        if (joules > 0F || itemStack.getTagCompound().hasKey("electricity"))
        {
            itemStack.getTagCompound().setFloat("electricity", electricityStored);
        }

        /** Sets the damage as a percentage to render the bar properly. */
        itemStack.setItemDamage(DAMAGE_RANGE - (int) (electricityStored / this.getMaxElectricityStored(itemStack) * DAMAGE_RANGE));
    }

    @Override
    public float getTransfer(ItemStack itemStack)
    {
        return Math.min(this.transferMax, this.getMaxElectricityStored(itemStack) - this.getElectricityStored(itemStack));
    }

    /**
     * Gets the energy stored in the item. Energy is stored using item NBT
     */
    @Override
    public float getElectricityStored(ItemStack itemStack)
    {
        if (itemStack.getTagCompound() == null)
        {
            itemStack.setTagCompound(new NBTTagCompound());
        }
        float energyStored = 0f;
        if (itemStack.getTagCompound().hasKey("electricity"))
        {
            NBTBase obj = itemStack.getTagCompound().getTag("electricity");
            if (obj instanceof NBTTagDouble)
            {
                energyStored = ((NBTTagDouble) obj).getFloat();
            } else if (obj instanceof NBTTagFloat)
            {
                energyStored = ((NBTTagFloat) obj).getFloat();
            }
        } else // First time check item - maybe from addInformation() in a JEI
               // recipe display?
        {
            if (itemStack.getItemDamage() == DAMAGE_RANGE)
                return 0F;

            energyStored = this.getMaxElectricityStored(itemStack) * (DAMAGE_RANGE - itemStack.getItemDamage()) / DAMAGE_RANGE;
            itemStack.getTagCompound().setFloat("electricity", energyStored);
        }

        /** Sets the damage as a percentage to render the bar properly. */
        itemStack.setItemDamage(DAMAGE_RANGE - (int) (energyStored / this.getMaxElectricityStored(itemStack) * DAMAGE_RANGE));
        return energyStored;
    }

    @Override
    public void getSubItems(CreativeTabs tab, NonNullList<ItemStack> list)
    {
        if (tab == GalacticraftCore.galacticraftItemsTab || tab == CreativeTabs.SEARCH)
        {
            list.add(ElectricItemHelper.getUncharged(new ItemStack(this)));
            list.add(ElectricItemHelper.getWithCharge(new ItemStack(this), this.getMaxElectricityStored(new ItemStack(this))));
        }
    }

    public static boolean isElectricItem(Item item)
    {
        if (item instanceof IItemElectricBase)
        {
            return true;
        }

        if (EnergyConfigHandler.isIndustrialCraft2Loaded())
        {
            if (item instanceof ic2.api.item.ISpecialElectricItem)
            {
                return true;
            }
        }

        return false;
    }

    public static boolean isElectricItemEmpty(ItemStack itemstack)
    {
        if (itemstack.isEmpty())
        {
            return false;
        }
        Item item = itemstack.getItem();

        if (item instanceof IItemElectricBase)
        {
            return ((IItemElectricBase) item).getElectricityStored(itemstack) <= 0;
        }

        if (EnergyConfigHandler.isIndustrialCraft2Loaded())
        {
            if (item instanceof ic2.api.item.IElectricItem)
            {
                return !((ic2.api.item.IElectricItem) item).canProvideEnergy(itemstack);
            }
        }

        return false;
    }

    public static boolean isElectricItemCharged(ItemStack itemstack)
    {
        if (itemstack == null)
            return false;
        Item item = itemstack.getItem();

        if (item instanceof IItemElectricBase)
        {
            return ((IItemElectricBase) item).getElectricityStored(itemstack) > 0;
        }

        if (EnergyConfigHandler.isIndustrialCraft2Loaded())
        {
            if (item instanceof ic2.api.item.IElectricItem)
            {
                return ((ic2.api.item.IElectricItem) item).canProvideEnergy(itemstack);
            }
        }

        return false;
    }

    // For RF compatibility

    public int receiveEnergy(ItemStack container, int maxReceive, boolean simulate)
    {
        return (int) (this.recharge(container, maxReceive * EnergyConfigHandler.RF_RATIO, !simulate) / EnergyConfigHandler.RF_RATIO);
    }

    public int extractEnergy(ItemStack container, int maxExtract, boolean simulate)
    {
        return (int) (this.discharge(container, maxExtract / EnergyConfigHandler.TO_RF_RATIO, !simulate) * EnergyConfigHandler.TO_RF_RATIO);
    }

    public int getEnergyStored(ItemStack container)
    {
        return (int) (this.getElectricityStored(container) * EnergyConfigHandler.TO_RF_RATIO);
    }

    public int getMaxEnergyStored(ItemStack container)
    {
        return (int) (this.getMaxElectricityStored(container) * EnergyConfigHandler.TO_RF_RATIO);
    }

    // The following seven methods are for Mekanism compatibility

    @Method(modid = CompatibilityManager.modidMekanism)
    public double getEnergy(ItemStack itemStack)
    {
        return this.getElectricityStored(itemStack) * EnergyConfigHandler.TO_MEKANISM_RATIO;
    }

    @Method(modid = CompatibilityManager.modidMekanism)
    public void setEnergy(ItemStack itemStack, double amount)
    {
        this.setElectricity(itemStack, (float) amount * EnergyConfigHandler.MEKANISM_RATIO);
    }

    @Method(modid = CompatibilityManager.modidMekanism)
    public double getMaxEnergy(ItemStack itemStack)
    {
        return this.getMaxElectricityStored(itemStack) * EnergyConfigHandler.TO_MEKANISM_RATIO;
    }

    @Method(modid = CompatibilityManager.modidMekanism)
    public double getMaxTransfer(ItemStack itemStack)
    {
        return this.transferMax * EnergyConfigHandler.TO_MEKANISM_RATIO;
    }

    @Method(modid = CompatibilityManager.modidMekanism)
    public boolean canReceive(ItemStack itemStack)
    {
        return (itemStack != null && !(itemStack.getItem() instanceof ItemBatteryInfinite));
    }

    public boolean canSend(ItemStack itemStack)
    {
        return true;
    }

    // All the following methods are for IC2 compatibility

    @Method(modid = CompatibilityManager.modidIC2)
    public IElectricItemManager getManager(ItemStack itemstack)
    {
        return (IElectricItemManager) ItemElectricBase.itemManagerIC2;
    }

    @Method(modid = CompatibilityManager.modidIC2)
    public boolean canProvideEnergy(ItemStack itemStack)
    {
        return true;
    }

    @Method(modid = CompatibilityManager.modidIC2)
    public int getTier(ItemStack itemStack)
    {
        return 1;
    }

    @Method(modid = CompatibilityManager.modidIC2)
    public double getMaxCharge(ItemStack itemStack)
    {
        return this.getMaxElectricityStored(itemStack) / EnergyConfigHandler.IC2_RATIO;
    }

    @Method(modid = CompatibilityManager.modidIC2)
    public double getTransferLimit(ItemStack itemStack)
    {
        return this.transferMax * EnergyConfigHandler.TO_IC2_RATIO;
    }
}

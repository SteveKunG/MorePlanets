/*
 * Copyright (c) 2023 Team Galacticraft
 *
 * Licensed under the MIT license.
 * See LICENSE file in the project root for details.
 */

@API(apiVersion = "1.0", owner = "galacticraftcore", provides = "GalacticraftAPI|transmission|grid")
package micdoodle8.mods.galacticraft.api.transmission.grid;

import net.minecraftforge.fml.common.API;
